<?php
class Customermap extends Portlet {
	protected function renderContent() {
		$this->render('customermap');
	}
}