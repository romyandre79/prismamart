<?php
class Top10supplierdebt extends Portlet {
	protected function renderContent() {
		$this->render('top10supplierdebt');
	}
}