<?php
class Suppliermap extends Portlet {
	protected function renderContent() {
		$this->render('suppliermap');
	}
}