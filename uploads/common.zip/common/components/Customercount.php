<?php
class Customercount extends Portlet {
	protected function renderContent() {
		$this->render('customercount');
	}
}