<?php
class Custsuppmap extends Portlet {
	protected function renderContent() {
		$this->render('custsuppmap');
	}
}