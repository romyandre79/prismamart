<?php
class Suppliercount extends Portlet {
	protected function renderContent() {
		$this->render('suppliercount');
	}
}