<?php
class Top10customerdebt extends Portlet {
	protected function renderContent() {
		$this->render('top10customerdebt');
	}
}